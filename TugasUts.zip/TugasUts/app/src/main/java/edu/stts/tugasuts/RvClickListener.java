package  edu.stts.tugasuts; 
import android.view.View;
public interface RvClickListener 
{     
    public void recycleviewClicked(View v,int post);
}