package edu.stts.tugasuts;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.menu.MenuAdapter;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rview;
    private EditText ednama;
    private TextView tvQty,tvTotal,tvName;
    private RadioGroup rgsemua;
    private RadioButton rbTea,rbSmoothies,rbCoffee;
    private CheckBox cbPearl,cbCoconut,cbRedBean,cbPudding;
    private OrderAdapter adapter;
    private ArrayList<Order> orderList = new ArrayList<>();
    int totalsemua=0;
    int index=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cbPearl = findViewById(R.id.checkBox_pearl);
        cbCoconut = findViewById(R.id.checkBox_coconut);
        cbRedBean = findViewById(R.id.checkBox_red_bean);
        cbPudding = findViewById(R.id.checkBox_pudding);
        rbTea = findViewById(R.id.radioButton_tea);
        rbSmoothies = findViewById(R.id.radioButton_smoothies);
        rbCoffee = findViewById(R.id.radioButton_coffee);
        rgsemua = findViewById(R.id.RadioGroup_type);
        tvQty = findViewById(R.id.textView_qty);
        tvTotal = findViewById(R.id.textView_total);
        tvName = findViewById(R.id.textView_name);
        ednama = findViewById(R.id.editText_name);
        rview=findViewById(R.id.RvMenu);
        adapter = new OrderAdapter(orderList, new RvClickListener() {
            @Override
            public void recycleviewClicked(View v, int post) {
                reset();
                index=post;
                tvQty.setText(String.valueOf(orderList.get(index).getQty()));
                if(orderList.get(post).getType().equalsIgnoreCase("Tea")){rbTea.setChecked(true);}
                else if(orderList.get(post).getType().equalsIgnoreCase("Coffee")){rbCoffee.setChecked(true);}
                else if(orderList.get(post).getType().equalsIgnoreCase("Smoothies")){rbSmoothies.setChecked(true);}
                if(orderList.get(post).getToppings().contains("Pudding")){cbPudding.setChecked(true);}
                if(orderList.get(post).getToppings().contains("Pearl")){cbPearl.setChecked(true);}
                if(orderList.get(post).getToppings().contains("Coconut")){cbCoconut.setChecked(true);}
                if(orderList.get(post).getToppings().contains("Red Bean")){cbRedBean.setChecked(true);}
            }
        });
        //RecyclerView.LayoutManager lm = new LinearLayoutManager(MainActivity.this);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(MainActivity.this);
        rview.setLayoutManager(lm);
        rview.setAdapter(adapter);
        rbTea.setChecked(true);
    }

    public void btnminusClick(View v)
    {
        int qty = Integer.valueOf(tvQty.getText().toString());
        if(qty-1>0) {qty--;}
        tvQty.setText(String.valueOf(qty));
    }
    public void btnplusClick(View v)
    {
        int qty = Integer.valueOf(tvQty.getText().toString());
        tvQty.setText(String.valueOf(++qty));
    }

    public void btnDelClick(View v)
    {
        if(index!=-1) {
            totalsemua -= orderList.get(index).getSubtotal();
            orderList.remove(index);
            index = -1;
            adapter.notifyDataSetChanged();
            tvTotal.setText("Total: RP "+String.valueOf(totalsemua));
            Toast.makeText(MainActivity.this,"Berhasil Delete", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(MainActivity.this,"Pilih dulu yang mau didelete", Toast.LENGTH_LONG).show();
        }
    }
    public void reset()
    {
        cbPearl.setChecked(false);
        cbPudding.setChecked(false);
        cbRedBean.setChecked(false);
        cbCoconut.setChecked(false);
        rbTea.setChecked(true);
    }
    public void btnResetClick(View v)
    {
        tvTotal.setText("Total:RP 0");
        tvName.setText("Hi,User!");
        ednama.setText("");
        tvQty.setText("1");
        totalsemua=0;
        index=-1;
        reset();
        orderList.clear();
        adapter.notifyDataSetChanged();

    }
    public void btnaddClick(View v)
    {
        if(!ednama.getText().toString().equalsIgnoreCase(""))
        {
            int pilihan = rgsemua.getCheckedRadioButtonId();
            int total=0; int jumlah=Integer.valueOf(tvQty.getText().toString());
            RadioButton rb = findViewById(pilihan);
            if(rb.getText().toString().equalsIgnoreCase("Tea")) {total+=22000;}
            else if(rb.getText().toString().equalsIgnoreCase("Smoothies")) {total+=30000;}
            else if(rb.getText().toString().equalsIgnoreCase("Coffee")) {total+=25000;}
            ArrayList<String> toppings = new ArrayList<>();
            if(cbCoconut.isChecked()) {toppings.add("Coconut");total+=4000;}
            if(cbRedBean.isChecked()) {toppings.add("Red Bean");total+=4000;}
            if(cbPudding.isChecked()) {toppings.add("Pudding");total+=3000;}
            if(cbPearl.isChecked()) {toppings.add("Pearl");total+=3000;}
            orderList.add(new Order(rb.getText().toString(),toppings,jumlah,jumlah*total));
            totalsemua += jumlah*total;
            adapter.notifyDataSetChanged();
            tvName.setText("Hi, "+ednama.getText().toString()+"!");
            tvTotal.setText("Total: RP "+String.valueOf(totalsemua));
        }
        else
        {

            Toast.makeText(MainActivity.this,"Isi dulu nama anda", Toast.LENGTH_LONG).show();
        }

    }
}
