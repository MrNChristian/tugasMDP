package edu.stts.tugasuts;

import android.support.annotation.NonNull;
import android.support.v7.view.menu.MenuAdapter;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {

    private static RvClickListener mylistener;
    //menentukan data arraylist akan ditampilkan pada recycle view
    private ArrayList<Order> orderlist;
    public OrderAdapter(ArrayList<Order> listorder ,RvClickListener exec)
    {
        this.orderlist = listorder;
        mylistener = exec;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View v = inflater.inflate(R.layout.rowitemorder, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        //mengisi widget dengan data dari arraylist
        String temp="";
        if(orderlist.get(i).getToppings().contains("Pudding")){temp+="Pudding ";}
        if(orderlist.get(i).getToppings().contains("Red Bean")){temp+="Red Bean ";}
        if(orderlist.get(i).getToppings().contains("Pearl")){temp+="Pearl ";}
        if(orderlist.get(i).getToppings().contains("Coconut")){temp+="Coconut ";}
        viewHolder.tvsubtotal.setText("Subtotal RP. "+String.valueOf(orderlist.get(i).getSubtotal()));
        viewHolder.tvtopping.setText(temp);
        viewHolder.tvtype.setText(orderlist.get(i).getType());
        viewHolder.tvqty.setText(String.valueOf(orderlist.get(i).getQty()));
    }

    @Override
    public int getItemCount() {
        return (orderlist!=null)?orderlist.size():0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView tvsubtotal,tvtopping,tvqty,tvtype;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvsubtotal =itemView.findViewById(R.id.textView_subtotal);
            tvtopping =itemView.findViewById(R.id.textView_toppings);
            tvqty =itemView.findViewById(R.id.textView_qty_type);
            tvtype =itemView.findViewById(R.id.textView_Type);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mylistener.recycleviewClicked(v,ViewHolder.this.getLayoutPosition());
                }
            });
        }
    }
}
